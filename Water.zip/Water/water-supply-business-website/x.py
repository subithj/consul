# def  f(x, n):
#     ch = {i: [] for  i in range(n)}
#     for i, j in enumerate(x):
#         if j != -1:
#             ch[j].append(i)
#     def  dfs(node, depth):
#         nonlocal  maxi
#         maxi = max(maxi, depth)
#         for i in ch[node]:
#             dfs(i, depth + 1)
#     maxi = 0
#     dfs(x.index(-1), 0)
#     return maxi

# n =  int(input())
# x = [int(input()) for  i  in range(n)]
# print(f(x,n))

b =[[0]*13 for _ in range(13)]
x = input()
map =  {'A': 1}
add =  y = 0
ans =  0
arr =  []
for i in range(0, len(x+)- 1, 2):
    m = map[x[i]]+2
    n = int(x[i+1])+2
    for di, dj in [(2,1),(1,2),(-1,2),(-2,1),(-2,-1),(-1,-2),(1,-2),(2,-1)]:
        b[m+di][n+dj] += 1
        if b[m+di][n+dj] > add:
            add = b[m+di][n+dj]
            y =  (m+di,n+dj)
for i in range(3, 3+8):
    for  j in range(3, 3+8):
        if b[i][j] == 0:
            ans +=  1
        if b[i][j] == add:
            arr.append((i,j))
print(ans)
if len(arr) == 1:
    print(chr(y[0]+62),chr(y[1]-2))
else:
    print(-1)